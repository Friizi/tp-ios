/*:
 ## Exercice - Tableaux
 
 Supposons que vous êtes un coordinateur d'événement pour un événement sportif et que vous gardiez une liste des personnes inscrites.
  
  Créez un tableau mutable vide 'listeInscription' qui stockera des chaînes de caractères.
*/
/*:
 - callout(Rappel):
    - Un tableau de valeurs `String` est associé au type `[String]`
    - Un type suivi de parenthèses permet de créer une instance de ce type
 */
var listeInscription : [String] = []
/*:
 Votre amie Sara est la première à s'inscrire à l'événement. Ajoutez son nom à 'listeInscription' en utilisant la méthode 'append'. Affichez le contenu du tableau.
 */
listeInscription.append("Sara")
/*:
 Ajoutez quatre noms supplémentaires dans le tableau en utilisant l'opérateur '+ ='. Tous les noms doivent être ajoutés en une seule étape. Affichez le contenu de la collection.
 */
listeInscription += ["nom1","nom2","nom3", "nom4"]
/*:
 Utilisez la méthode 'insert (_: at :)' pour ajouter 'Charlie' dans le tableau en tant que second élément. Affichez le contenu de la collection.
 */
listeInscription.insert("Charlie", at:1)
/*:
 Une personne n'est pas en forme et souhaite laisser sa place à quelqu'un d'autre. Utilisez l'indice de tableau pour changer le sixième élément en 'Rebecca'. Affichez le contenu de la collection.
 */
listeInscription[5] = "Rebecca"
/*:
Appelez 'removeLast()' sur 'listeInscription'. Si cela est fait correctement, cela devrait supprimer «Rebecca» du tableau. Stockez le résultat de 'removeLast()' dans une nouvelle constante 'elementSupprime', puis imprimez 'deletedItem'.
 */
// Vérification que le tableau n'est pas vide avant de retirer le dernier élément
let elementSupprime = listeInscription.removeLast()

// Affichage de l'élément supprimé
print("Élément supprimé : \(elementSupprime)")

print("État actuel de la liste d'inscription : \(listeInscription)")
//: page 1 / 3  |  [Suivant : Exercice d'application - Défi d'activité](@next)
