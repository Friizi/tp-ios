/*:
 ## Exercice d'application - Défi d'activité
 
 >Ces exercices renforcent les concepts de Swift dans le contexte d'une application de suivi de la condition physique.
 
 Votre application de suivi de la condition physique montre aux utilisateurs une liste de défis possibles, regroupés par type d'activité (défis de marche, défis de course, défis gymniques, défis d'haltérophilie, etc.). Un défi peut-être  "marcher 5 km par jour" ou "Courir 5 fois par semaine."
 
 En utilisant des tableaux de type 'String', créez au moins deux listes, une pour les défis de marche, et une pour les défis de course. Chaque liste doit avoir au moins deux défis et doit être initialisée en utilisant un tableau. N'hésitez pas à créer des liste supplémentaires pour d'autres activités.
 */
var listeDefisMarche: [String] = ["Marcher 5 km par jour", "Marcher 10 km par jour"]
var listeDefisCourse: [String] = ["Courir 5 fois par semaine.", "Courir 10 fois par semaine."]
/*:
 Dans votre application, vous souhaitez afficher toutes ces listes sur le même écran regroupées en sections. Créez un tableau 'defis' qui contient chacune des listes que vous avez créées (ce sera un tableau de tableaux). En utilisant 'defis', affichez le premier élément de la deuxième liste de 'defis'.
 */
var defis = [listeDefisMarche, listeDefisCourse]

print(defis[1][0])
/*:
 Tous les défis seront réinitialisés à la fin du mois. Utilisez 'removeAll' pour supprimer tous les 'défis'. Affichez 'défis'.
 */
defis[0].removeAll()
defis[1].removeAll()

print(defis)
 
/*:
 Créez un nouveau tableau de type 'String' qui représentera les défis auxquels un utilisateur s'est engagé. Il peut s'agir d'un tableau vide ou de quelques éléments.
 */
var DefisEngage: [String] = ["Running", "Running1"]


/*:
 Écrivez une instruction 'if' qui utilisera 'isEmpty' pour vérifier s'il y a quelque chose dans le tableau. Si ce n'est pas le cas, affichez une instruction demandant à l'utilisateur de s'engager dans un challenge. Ajoutez une instruction else-if qui affichera "Le défi que vous avez choisi est <INSERER LE DEFI CHOISI>" si la taille du tableaux est exactement 1. Ajoutez ensuite une autre instruction qui affichera "Vous avez choisi plusieurs défis !".
 */
if DefisEngage.isEmpty {
    print("Engagez-vous dans un challenter")
} else if DefisEngage.count == 1 {
    print("Le défi que vous avez choisi est",DefisEngage[0])
} else {
    print("Vous avez plusieurs défis !")
}
//: [Précédent : Exercice - Tableaux](@previous)  |  page 2 / 3  |  [Suivant : Exercice d'application - Stimulation](@next)
