/*:
 ## Exercice d'application - Stimulation
 
 >Ces exercices renforcent les concepts de Swift dans le contexte d'une application de suivi de la condition physique.
 
 Vous utilisez un dictionnaire pour permettre aux utilisateurs de stocker différentes allures auxquelles ils courrent régulièrement ou avec lesquelles ils s'entrainent en 'interval training'.
 
 Créez un dictionnaire 'allures' de type [String: Double] et attribuez-lui un dictionnaire avec les clés "Facile", "Medium" et "Rapide" correspondant aux valeurs 15.0, 12.0 et 9.0. Ces chiffres correspondent à l'allure au km en minutes. Affichez le dictionnaire.
 */
var allures: [String:Double] = ["Facile":9.0,"Medium":12.0,"Rapide":15.0]
print(allures)

/*:
 Ajouter une nouvelle paire clé / valeur au dictionnaire. La clé doit-être "Sprint" et la valeur doit-)être 6.0. Affichez le dictionnaire.
 */
allures["Sprint"] = 6.0
print(allures)


/*:
 Imaginez que l'utilisateur en question accélère au fil du temps et décide de mettre à jour son rythme de course. Mettez à jour les valeurs de "Medium" et "Rapide" à 11.3 et 8.7, respectivement. Imprime le dictionnaire.
 */
allures["Medium"] = 11.3
allures["Rapide"] = 8.7
print(allures)
/*:
 Imaginez que l'utilisateur en question décide de ne pas stocker "Sprint" comme l'une de ses allures régulières. Supprimer "Sprint" du dictionnaire. Affichez le dictionnaire.
 */
allures.removeValue(forKey: "Sprint")
print(allures)
/*:
 Lorsqu'un utilisateur choisit une allure, vous voulez que l'application affiche un message indiquant qu'elle le maintiendra à cette allure. Imaginez un utilisateur choisit "Moyen". En accédant à la valeur du dictionnaire, imprimez une déclaration en disant "Ok, je vous maintiens à une allure de <INSÉRER LA VALEUR D'ALLURE ICI> minutes au km."
 */
let mediumAllure = allures["Medium"] ?? 0.0
print("OK, je vous maintiens à une allure de", mediumAllure,"minutes au km")


/*:
 
 _Copyright © 2017 Apple Inc._
 
 _Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:_
 
 _The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software._
 
 _THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE._
 */
//: [Previous : Exercice d'application - Défi d'activité](@previous)  |  page 3 / 3

