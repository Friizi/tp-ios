/*:
 ## Exercice - Optionals

 Imaginez que vous avez une application qui demande à l'utilisateur d'entrer son âge au clavier. Lorsque votre application permet à un utilisateur de saisir le texte, ce qui est entré est considéré comme un 'String'. Cependant, vous voulez stocker cette information en tant que Int. Est-il possible que l'utilisateur fasse une erreur et que l'entrée ne corresponde pas au type que vous voulez stocker?
 
 Déclarez une constante userInputAge de type String et assignez-lui "34e" pour simuler une faute de frappe en tapant age. Puis déclarez une constante userAge de type Int et utilisez le constructeur 'Int()' et transmettez-le dans userInputAge. Quelle erreur obtenez-vous?
*/
var userInputAge : String = "34"
var userAge : Int? = Int(userInputAge)
print(userAge!)
/*:
 Revenez en arrière et modifiez le type de 'userAge' en 'Int?' et affichez la valeur de 'userAge'. Pourquoi la valeur "userAge" est-elle "nil"? Fournissez votre réponse dans un commentaire ou une déclaration d'impression ci-dessous.
 */
//La chaîne "34e" ne représente pas un nombre entier valide. Le constructeur Int() essaie de convertir la chaîne de caractères en un entier, mais puisque "34e" contient des caractères non numériques ("e"), cette conversion échoue. En Swift, lorsque la conversion échoue, le constructeur Int() retourne nil au lieu de provoquer une erreur ou un crash. Cela est conforme à la conception de Swift en matière de sécurité des types et de manipulation prudente des valeurs optionnelles.
/*:
 Maintenant corrigez la faute de frappe sur 'userInputAge'. Y a-t-il quelque chose sur la valeur affichée qui ne va pas?
 
 Affichez à nouveau 'userAge', mais cette fois, accompagnez 'userAge' de l'opérateur !.
 */
//L'avertissement "Expression implicitly coerced from 'Int?' to 'Any'" en Swift apparaît lorsque vous tentez d'utiliser une valeur optionnelle (Int? dans ce cas) dans un contexte où une valeur non-optionnelle est attendue. Cela se produit souvent lors de l'impression ou de la manipulation de valeurs optionnelles sans les avoir déballées de manière appropriée.
//L'utilisation de "!" pour corriger l'avertissement "Expression implicitly coerced from 'Int?' to 'Any'" en Swift est une approche valide à condition que vous soyez absolument sûr que userAge n'est pas nil. En utilisant l'opérateur de déballage forcé (!), vous dites explicitement au compilateur que vous savez que userAge contient une valeur non nil et que vous souhaitez déballer cette valeur.


/*:
 Utilisez maintenant une liaison optionnelle pour 'userAge'. Si 'userAge' a une valeur, affichez-la sur la console.
 */
if let age = userAge {
    print("La valeur de userAge est : \(age)")
} else {
    print("La conversion a échoué.")
}

//: page 1 / 3  |  [Suivant : Exercice d'application - Trouver un rythme cardiaque](@next)
