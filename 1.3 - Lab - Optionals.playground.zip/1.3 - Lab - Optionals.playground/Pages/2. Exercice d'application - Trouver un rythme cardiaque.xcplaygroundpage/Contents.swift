/*:
 ## Exercice d'application - Trouver un rythme cardiaque
 
 >Ces exercices renforcent les concepts de Swift dans le contexte d'une application de suivi de la condition physique.
 
 De nombreuses API vous fournissent des informations collectées par le matériel retourne des 'optionals'. Par exemple, une API pour travailler avec un moniteur de fréquence cardiaque peut vous donner 'nil' si le moniteur de fréquence cardiaque est mal ajusté et qu'elle ne peut pas lire correctement la fréquence cardiaque de l'utilisateur.
 
 Déclarez une variable 'frequenceCardiaque' de type 'Int?' et mettez-la à 'nil'. Affichez la valeur.
 */
var frequenceCardiaque : Int? = nil
print(frequenceCardiaque)
/*:
 Dans cet exemple, si l'utilisateur fixe le positionnement du moniteur de fréquence cardiaque, l'application peut obtenir une lecture correcte de la fréquence cardiaque. Ci-dessous, mettez à jour la valeur de 'frequenceCardiaque' à 74. Affichez la valeur.
 */
frequenceCardiaque = 74
print(frequenceCardiaque!)
/*:
 Créez une variable 'fcMoyenne' de type 'Int' et utilisez les valeurs stockées ci-dessous et la valeur de 'frequenceCardiaque' pour calculer une fréquence cardiaque moyenne.
 */
let ancienneFC1 = 80
let ancienneFC2 = 76
let ancienneFC3 = 79
let ancienneFC4 = 70


print()
/*:
 Si vous n'avez pas effectué une déclaration optionnelle de la valeur de 'frequenceCardiaque' , vous avez probablement remarqué que vous ne pouvez pas effectuer des opérations mathématiques avec une valeur optionnelle. Vous devez tout d'abord déclarer 'frequenceCardiaque'  optionnel.

 Déclarer la valeur de  'frequenceCardiaque' comme optionnelle en utilisant une liaison optionnelle. Si  'frequenceCardiaque' a une valeur, calculer la fréquence cardiaque moyenne en utilisant cette valeur et les anciennes fréquences cardiaques enregistrées ci-dessus. S'il n'a pas de valeur, calculez la fréquence cardiaque moyenne en utilisant uniquement les anciennes fréquences cardiaques. Dans chaque cas, afficher la valeur de 'fcMoyenne'.
 
 */


//: [Précédent : Exercice - Optionals](@previous)  |  page 2 / 3  |  [Suivant : Exercice - Fonctions et Optionals](@next)
