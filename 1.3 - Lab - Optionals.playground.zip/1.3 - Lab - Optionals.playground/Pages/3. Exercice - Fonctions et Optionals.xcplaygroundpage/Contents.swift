/*:
 ## Exercice - Fonctions et Optionals
 
 Une application peut demander l'âge d'un utilisateur pour utiliser certains services qu'elle fournit. Ecrivez une fonction appelée 'verifAge' qui prend un paramètre de type 'String'. La fonction doit essayer de convertir ce paramètre en une valeur Int, puis vérifier si l'utilisateur a plus de 18 ans. Si il est assez vieux, affichez "Bienvenue!", Sinon affichez "Désolé, mais vous n'êtes pas assez vieux pour utiliser notre application." Si le paramètre 'String' ne peut pas être converti en valeur 'Int', affichez "Désolé, il y a eu un problème. Pouvez-vous entrer à nouveau votre âge? " Appelez la fonction et transmettez 'userInputAge' ci-dessous en tant que paramètre unique. Appelez ensuite la fonction et transmettez une chaîne pouvant être convertie en entier.
 */
let userInputAge: String = "34e"



/*:
 Mettez à jour votre fonction pour qu'elle renvoie un entier pour l'âge. Votre fonction retournera-t-elle toujours une valeur? Assurez-vous que votre type de retour reflète bien cela. Appelez la fonction et affichez la valeur de retour.
 */

/*:
Imaginez que vous créez une application pour effectuer des achats. Ecrivez une fonction qui prendra le nom d'un objet à acheter en tant que 'String' et retournera le coût de cet article en tant que 'Double' optionnel. Dans le corps de la fonction, vérifiez si l'article est en stock en y accédant dans le dictionnaire 'stock'. Si c'est le cas, retournez le prix de l'article en y accédant dans le dictionnaire 'prix'. Si l'article est en rupture de stock, retournez 'nil'. Appelez la fonction et transmettez un 'String' qui existe dans les dictionnaires ci-dessous. Affichez la valeur de retour.
 */
var prix = ["Chips": 2.99, "Donuts": 1.89, "JusdeFruit": 3.99, "Pomme": 0.50, "Banane": 0.25, "Brocoli": 0.99]
var stock = ["Chips": 4, "Donuts": 0, "JusdeFruit": 12, "Pomme": 6, "Banane": 6, "Brocoli": 3]




//: [Précédent : Exercice d'application - Trouver un rythme cardiaque](@previous)  |  page 3 / 3
