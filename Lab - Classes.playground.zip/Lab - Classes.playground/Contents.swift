/*:
 ## Exercice - Créer une sous classe
 
 - Note: Les exercices ci-après sont basés sur un jeu où un vaisseau spatial évite les obstacles dans l'espace. Le navire est positionné au bas d'un système de coordonnées et ne peut se déplacer que vers la gauche et la droite pendant que les obstacles «tombent» de haut en bas. Dans les exercices suivants, vous allez créer les classes pour représenter les différents types de vaisseaux spatiaux qui peuvent être utilisés dans le jeu.
 
 Créez une classe 'VaisseauSpacial' avec trois attributs : 'nom , 'sante' et 'position'. La valeur par défaut de 'nom' est une chaîne vide et 'sante' vaut 100. 'position' est un entier, les nombres négatifs déplacent le vaisseau  à gauche et les nombres positifs déplacent le vaisseau à droite. Par défaut,'position' vaut 0.
 */
class VaisseauSpacial {
    var nom: String = ""
    var sante = 100
    var position = 0
    
    func deplaceGauche() {
        position -= 1
    }
    
    func deplaceDroite() {
        position += 1
    }
    
    func touche() {
        sante -= 5
    }
}
/*:
 Créez une constante appelée 'faucon' et lui affecter une instance de 'VaisseauSpacial'.
 Après l'initialisation, le 'nom'de cette constante sera "Faucon".
 */
let faucon = VaisseauSpacial()
faucon.nom = "Faucon"
/*:
 Revenez en arrière et ajoutez une méthode appelée 'deplaceGauche()' à la définition de 'VaisseauSpacial'. Cette méthode déplace la position du vaisseau spatial à gauche de un. Ajoutez une méthode similaire appelée 'deplaceDroite()' qui déplace le vaisseau vers la droite. Une fois que ces méthodes existent, utilisez-les pour déplacer le faucon vers la gauche deux fois et vers la droite une fois. Affichez la nouvelle position de 'faucon' après chaque changement de position.
 */

print(faucon.position)
faucon.deplaceGauche()
print(faucon.position)
faucon.deplaceGauche()
print(faucon.position)
faucon.deplaceDroite()
print(faucon.position)

/*:
 La dernière chose dont 'VaisseauSpacial' a besoin pour cet exemple est une méthode pour gérer ce qui se passe si le vaisseau est touché. Revenez en arrière et ajoutez une méthode 'touche()' à 'VaisseauSpacial' qui diminuera la santé du vaisseau de 5, et si 'sante' est inférieur ou égal à 0, il affichera "Désolé, votre vaisseau a été touché une fois de trop. Voulez-vous jouer à nouveau? ". Une fois que cette méthode existe, appelez-la sur 'faucon' et affichez la valeur de 'sante'.
 */
faucon.touche()
print(faucon.sante)
//: page 1 / 4 | [Next](@next)
