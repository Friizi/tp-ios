/*:
 ## Exercice - Créer une sous classe
 
 - Note: Les exercices ci-après sont basés sur un jeu où un vaisseau spatial évite les obstacles dans l'espace. Le vaisseau est positionné au bas d'un système de coordonnées et ne peut se déplacer que vers la gauche et la droite pendant que les obstacles «tombent» de haut en bas. Dans les exercices suivants, vous allez créer les classes pour représenter les différents types de vaisseaux spatiaux qui peuvent être utilisés dans le jeu. La classe de base 'VaisseauSpacial' est fournie.
 */
class VaisseauSpacial {
    var nom: String = ""
    var sante = 100
    var position = 0
    
    func deplaceGauche() {
        position -= 1
    }
    
    func deplaceDroite() {
        position += 1
    }
    
    func touche() {
        sante -= 5
    }
}
/*:
 Définir une nouvelle classe 'Combattant' qui hérite de 'VaisseauSpacial'. Ajoutez un attribut 'arme' qui est par défaut une chaîne vide et une propriété  'puissanceFeuRestante' qui est par défaut à 5.
 */
class Combattant: VaisseauSpacial {
    var arme: String
    var puissanceFeuRestante: Int
    
    init(arme: String = "", puissanceFeuRestante: Int = 5) {
        self.arme = arme
        self.puissanceFeuRestante = puissanceFeuRestante
    }
    
    func feu() {
        if self.puissanceFeuRestante > 0 {
            puissanceFeuRestante -= 1
        } else {
            print("Vous n'avez plus de puissance de feu")
        }
    }
}
/*:
 Créez une  instance de 'Combattant' appelée 'destructeur'. Un combattant sera capable de tirer sur les objets entrants pour éviter de heurter les objets. Après l'initialisation, définissez 'arme' à "Laser" et 'puissanceFeuRestante' à 10. Notez que puisque 'Combattant' hérite de 'VaisseauSpacial', il a aussi des propriétés pour 'nom', 'sante' et 'position', et des méthodes pour 'deplaceGauche()', 'deplaceDroite()', et 'touche()' même si vous ne les avez pas spécifiquement ajoutées à la déclaration de 'Combattant'. Sachant cela, initialiser 'nom' à "Destructeur", affichez 'position', puis appelez 'deplaceDroite()' et affichez 'position' à nouveau.
 */
// Création de l'instance 'destructeur'
var destructeur = Combattant()

// Initialisation des propriétés
destructeur.nom = "Destructeur"
destructeur.arme = "Laser"
destructeur.puissanceFeuRestante = 10

// Affichage de la position initiale
print("Position initiale : \(destructeur.position)")

// Déplacement du combattant à droite
destructeur.deplaceDroite()

// Affichage de la nouvelle position
print("Position après déplacement : \(destructeur.position)")
/*:
 Essayez d'afficher 'arme' sur 'faucon'. Pourquoi ça ne marche pas ? Donnez votre réponse dans un commentaire et supprimez tout code que vous avez ajouté et qui ne sera pas compilé.
 */
// Assurez-vous que 'faucon' est une instance de 'Combattant' pour accéder à la propriété 'arme'.
// Par exemple, si 'faucon' est déclaré comme suit, l'affichage de 'arme' fonctionnera :
// var faucon = Combattant()
// print(faucon.arme)

/*:
 Ajoutez une méthode à 'Combattant' appelée 'feu()'. Cette méthode vérifie si 'puissanceFeuRestante' est supérieur à 0, et si c'est le cas, elle décrémente 'puissanceFeuRestante' de un. Si 'puissanceFeuRestante' n'est pas supérieure à 0, affichez " Vous n'avez plus de puissance de feu ". Appelez 'feu()' sur 'destructeur' plusieurs fois et affichez 'puissanceFeuRestante' après chaque appel de méthode.
 
 */
destructeur.feu()
print("Puissance de feu restante :  \(destructeur.puissanceFeuRestante)")
destructeur.feu()
print("Puissance de feu restante :  \(destructeur.puissanceFeuRestante)")
destructeur.feu()
print("Puissance de feu restante :  \(destructeur.puissanceFeuRestante)")
destructeur.feu()
print("Puissance de feu restante :  \(destructeur.puissanceFeuRestante)")
destructeur.feu()
print("Puissance de feu restante :  \(destructeur.puissanceFeuRestante)")
destructeur.feu()
print("Puissance de feu restante :  \(destructeur.puissanceFeuRestante)")
destructeur.feu()
print("Puissance de feu restante :  \(destructeur.puissanceFeuRestante)")
destructeur.feu()
print("Puissance de feu restante :  \(destructeur.puissanceFeuRestante)")
destructeur.feu()
print("Puissance de feu restante :  \(destructeur.puissanceFeuRestante)")
destructeur.feu()
print("Puissance de feu restante :  \(destructeur.puissanceFeuRestante)")
destructeur.feu()
print("Puissance de feu restante :  \(destructeur.puissanceFeuRestante)")
destructeur.feu()
print("Puissance de feu restante :  \(destructeur.puissanceFeuRestante)")
destructeur.feu()
print("Puissance de feu restante :  \(destructeur.puissanceFeuRestante)")
destructeur.feu()
print("Puissance de feu restante :  \(destructeur.puissanceFeuRestante)")
destructeur.feu()
print("Puissance de feu restante :  \(destructeur.puissanceFeuRestante)")
destructeur.feu()
print("Puissance de feu restante :  \(destructeur.puissanceFeuRestante)")
destructeur.feu()
print("Puissance de feu restante :  \(destructeur.puissanceFeuRestante)")
destructeur.feu()
print("Puissance de feu restante :  \(destructeur.puissanceFeuRestante)")
destructeur.feu()
print("Puissance de feu restante :  \(destructeur.puissanceFeuRestante)")
destructeur.feu()
print("Puissance de feu restante :  \(destructeur.puissanceFeuRestante)")
//: [Précédent : Exercice - Définir une classe de base](@previous) | page 2 / 4  |  [Suivant : Exercice - Surcharger les propriétés et méthodes](@next)

