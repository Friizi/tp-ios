/*:
 ## Exercice - Surcharge des propriétés et méthodes
 
 - Note: Les exercices ci-après sont basés sur un jeu où un vaisseau spatial évite les obstacles dans l'espace. Le vaisseau est positionné au bas d'un système de coordonnées et ne peut se déplacer que vers la gauche et la droite pendant que les obstacles «tombent» de haut en bas. Dans les exercices suivants, vous allez créer les classes pour représenter les différents types de vaisseaux spatiaux qui peuvent être utilisés dans le jeu. La classe de base 'VaisseauSpatial' et  une classe enfant 'Combattant' sont fournies.
*/
class VaisseauSpatial {
    var nom: String = ""
    var sante = 100
    var position = 0
    
    func deplaceGauche() {
        position -= 1
    }
    
    func deplaceDroite() {
        position += 1
    }
    
    func touche() {
        if sante > 0 {
            sante -= 5
        } else {
            print("Désolé, votre vaisseau a été touché une fois de trop. Voulez-vous jouer à nouveau?")
        }
    }
}

class Combattant: VaisseauSpatial {
    var arme = ""
    var puissanceFeuRestante = 5
    
    func feu() {
        if puissanceFeuRestante > 0 {
            puissanceFeuRestante -= 1
        } else {
            print("Vous n'avez plus de puissance de feu.")
        }
    }
}
/*:
 Définissez une nouvelle classe 'VaisseauBlinde' qui hérite de 'Combattant'. Ajoutez une propriété 'forceBouclier' à 25 par défaut. Créez une nouvelle instance de 'VaisseauBlinde' appelée 'defenseur' dont le nom est "Defenseur" et l'arme est "Canon". Appelez 'deplaceDroite()' et affichez 'position', puis appelez 'feu()' et affichez 'puissanceFeuRestante'.
 */
class VaisseauBlinde: Combattant {
    var forceBouclier: Int = 25
    
    override func touche() {
        if forceBouclier > 0 {
            forceBouclier -= 5
        } else {
            super.touche()
        }
    }
}

var defenseur = VaisseauBlinde()

defenseur.nom = "Defenseur"
defenseur.arme = "Canon"

defenseur.deplaceDroite()

print("position : ",defenseur.position)

defenseur.feu()

print("Puissance de feu restante : ",defenseur.puissanceFeuRestante)


/*:
   Revenez à votre déclaration de 'VaisseauBlinde' et surcharger 'touche()'. Dans le corps de la méthode, vérifiez si 'forceBouclier' est supérieure à 0. Si c'est le cas, décrémentez 'forceBouclier' de 5. Sinon, décrémentez 'sante' de 5. Appelez 'touche()' sur 'defenseur' et afficher 'forceBouclier' et 'sante'.
 */
defenseur.touche()
print("Force du bouclier : ",defenseur.forceBouclier)
print("Sante : ",defenseur.sante)
/*:
  Quand 'forceBouclier' vaut 0, 'touche()' décrémente 'sante' de 5. C'est exactement ce que fait l'implémentation de 'touche()' sur 'VaisseauSpatial' ! Au lieu de tout réécrire, vous pouvez appeler la méthode 'touche()' de la classe parent. Revenez à votre implémentation de 'touche()' sur 'VaisseauBlinde' et supprimez le code où vous décrémentez 'santé' de 5 et remplacez-le par un appel de la méthode de la classe parent. Appelez 'touche()' sur 'defenseur', puis affichez 'forceBouclier' et 'sante'.
 */
defenseur.touche()
print("Force du bouclier : ",defenseur.forceBouclier)
print("Sante : ",defenseur.sante)


defenseur.touche()
defenseur.touche()
defenseur.touche()
defenseur.touche()
defenseur.touche()
defenseur.touche()
defenseur.touche()
defenseur.touche()
defenseur.touche()
defenseur.touche()
defenseur.touche()
defenseur.touche()
defenseur.touche()
defenseur.touche()
defenseur.touche()
defenseur.touche()
defenseur.touche()
defenseur.touche()
defenseur.touche()
defenseur.touche()
defenseur.touche()
defenseur.touche()
defenseur.touche()
defenseur.touche()
print("Force du bouclier : ",defenseur.forceBouclier)
print("Sante : ",defenseur.sante)

//: [Précédent : Exercice - Créer une classe enfant](@previous) | page 3 / 4  |  [Suivant : Exercice - Constructeurs](@next)
