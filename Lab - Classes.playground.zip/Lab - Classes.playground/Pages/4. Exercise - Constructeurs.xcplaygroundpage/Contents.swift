/*:
 ## Exercice - Constructeurs
 
 - Note: Les exercices ci-après sont basés sur un jeu où un vaisseau spatial évite les obstacles dans l'espace. Le navire est positionné au bas d'un système de coordonnées et ne peut se déplacer que vers la gauche et la droite pendant que les obstacles «tombent» de haut en bas. Dans les exercices suivants, vous allez créer les classes pour représenter les différents types de vaisseaux spatiaux qui peuvent être utilisés dans le jeu. La classe de base 'VaisseauSpatial' et  les classes enfant 'Combattant' et 'VaisseauBlinde' sont fournies.
 */
class VaisseauSpatial {
    var nom: String = ""
    var sante = 100
    var position = 0
    
    init(nom: String, sante: Int, position: Int) {
        self.nom = nom
        self.sante = sante
        self.position = position
    }
    
    func deplaceGauche() {
        position -= 1
    }
    
    func deplaceDroite() {
        position += 1
    }
    
    func touche() {
        sante -= 5
    }
}

class Combattant: VaisseauSpatial {
    var arme = ""
    var puissanceFeuRestante = 5
    
    init(nom: String, sante: Int, position: Int, arme: String, puissanceFeuRestante: Int) {
        self.arme = arme
        self.puissanceFeuRestante = puissanceFeuRestante
        super.init(nom: nom, sante: sante, position: position)
    }
    
    func feu() {
        if puissanceFeuRestante > 0 {
            puissanceFeuRestante -= 1
        } else {
            print("Vous n'avez plus de puissance de feu.")
        }
    }
}



class VaisseauBlinde: Combattant {
    var forceBouclier = 25
    
    init(nom: String, sante: Int, position: Int, arme: String, puissanceFeuRestante: Int, forceBouclier: Int) {
        self.forceBouclier = forceBouclier
        super.init(nom: nom, sante: sante, position: position, arme: arme, puissanceFeuRestante: puissanceFeuRestante)
    }
    
    override func touche() {
        if forceBouclier > 0 {
            forceBouclier -= 5
        } else {
            super.touche()
        }
    }
}

/*:
 Notez que chaque classe ci-dessus a une erreur lors de la déclaration de la classe qui dit "La classe n'a pas de constructeur." Contrairement aux structures, les classes ne sont pas fournies avec des constructeurs membres, car les constructeurs membres standards ne fonctionnent pas toujours bien avec l'héritage. Vous pouvez vous débarrasser de l'erreur en fournissant des valeurs par défaut pour tout, mais il est courant, et de meilleure pratique, d'écrire simplement votre propre constructeur. Reprendre la déclaration de 'VaisseauSpatial' et ajouter un constructeur qui prend un argument pour chaque propriété de 'VaisseauSpatial' et définit les propriétés en conséquence.
 Ensuite, créez une instance de 'VaisseauSpatial'  appelée 'faucon'. Utilisez le constructeur membre que vous venez de créer. Le nom du navire devrait être "Faucon".
 */
var faucon = VaisseauSpatial(nom: "Faucon", sante: 100, position: 0)
/*:
 L'écriture de constructeurs pour les classes enfant peut s'avérer difficile. Votre initialiseur doit non seulement définir les propriétés déclarées dans la classe enfant, mais également définir toutes les propriétés non initialisées sur les classes dont il hérite. Allez à la déclaration de 'Combattant' et écrivez un constructeur qui prend un argument pour chaque propriété de 'Combattant' et pour chaque propriété de 'VaisseauSpatial'. Définissez les propriétés en conséquence.
 (Indice: vous pouvez appeler le constructeur d'une classe parent avec 'super.init' * après * l'initialisation de toutes les propriétés de la classe enfant). Ensuite, créez une instance de 'Combattant' ci-dessous appelée 'destructeur'. Utilisez le constructeur membre que vous venez de créer. Le nom du navire sera "Destructeur".
 */
var destructeur = Combattant(nom: "Destructeur", sante: 100, position: 0, arme: "Laser", puissanceFeuRestante: 5)
/*:
 Maintenant, ajoutez un constructeur à 'VaisseauBlinde' qui prend un argument pour chaque propriété sur 'VaisseauBlinde', 'Combattant', et 'VaisseauSpatial', et définit les propriétés en conséquence. Rappelez-vous que vous pouvez appeler le constructeur sur 'Combattant' en utilisant 'super.init'.
   
     Ensuite, créez une instance de 'VaisseauBlinde' ci-dessous appelée 'defenseur'. Utilisez le constructeur membre que vous venez de créer. Le nom du navire sera "Défenseur".
 */
var défenseur = VaisseauBlinde(nom: "Défenseur", sante: 100, position: 0, arme: "Laser", puissanceFeuRestante: 5, forceBouclier: 5)
/*:
 Créez une nouvelle instance de 'VaisseauSpatial' appelée 'vaisseau' et définissez-la égale à 'faucon'. Affichez la position de 'vaisseau' et 'faucon', puis appelez 'deplaceGauche()' sur 'vaisseau' et affichez à nouveau la position de 'vaisseau' et 'faucon'. Les deux positions ont-elles changé ? Pourquoi ? Si les deux étaient des structures plutôt que des classes, serait-ce la même chose? Pourquoi ou pourquoi pas? Fournissez votre réponse dans un commentaire  ci-dessous.
 */
var vaisseau = faucon

print("Faucon position : ",faucon.position)
print("Vaisseau position : ",vaisseau.position)

vaisseau.deplaceGauche()

print("Vaisseau position : ",vaisseau.position)
print("Faucon position : ",faucon.position)

//  En Swift, les classes sont des types de référence. Cela signifie que lorsque nous assignons 'vaisseau' à 'faucon', 'vaisseau' ne devient pas une copie indépendante de 'faucon', mais plutôt une référence au même objet. Par conséquent, lorsque 'vaisseau.deplaceGauche()' est appelé, cela affecte l'objet partagé, modifiant la 'position' de 'faucon' aussi. Ainsi, les deux positions changent.
/*:
 
 _Copyright © 2017 Apple Inc._
 
 _Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:_
 
 _The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software._
 
 _THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE._
 */

//: [Précédent : Exercice - Surcharge des propriétés et méthodes](@previous) | page 4 / 4  
